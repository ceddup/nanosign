# nanosign
A siple way to make a 'NANO ACCEPTED HERE' sign with QRCode
